# Restless Otter Solution Notes

These notes follow the current binary (`restlessOtter`, SHA-256 `66cde9e0…`, rebuilt on macOS and stripped). `instructor.md` in this folder has the full key, with addresses and verification steps.

## Running the program

- No argument (or more than one): prints the banner and a usage line, then exits with code 1. No config, network, or ticket steps run.
- Exactly one argument: decodes the config, runs the DNS and HTTP steps, runs the anti-debug check, then checks the ticket.

## Runtime Config

The encrypted config blob decodes to:

```text
host=github.com;path=/;dns=example.com;campaign=operation-tidepool;agent=restlessotter-lab/3.0
```

The current build does not print the decoded config. Students recover it from the code.

## Network

With one argument, the binary resolves `example.com`, resolves `github.com`, then opens a TCP connection to `github.com:80` and sends this request:

```text
GET / HTTP/1.0
Host: github.com
User-Agent: restlessotter-lab/3.0
Connection: close
```

The current build prints nothing for these steps, whether they succeed or fail. The only evidence of them is the network traffic in a sandbox capture.

## Ticket

The correct ticket is:

```text
TIDEPOOL-MAC-026
```

The validation loop requires 16 bytes. For each byte `i`:

```c
v = ticket[i] ^ (0x41 + i * 13);
v = v + i * 7 + 0x23;
v = rol8(v, (i % 5) + 1);
/* must equal SERIAL_TABLE[i] */
```

The loop also updates a rolling checksum, which must finish at `0x7c539eb9`.

## Flag

With the correct ticket, the encrypted flag blob decrypts to:

```text
RO{MAC_OTTER_CURRENT}
```

Output on success is `[+] ticket accepted.` followed by the flag. Exit code 0.

## Anti-debug

If the process is being traced on macOS, the sysctl check reads the `P_TRACED` flag. The program prints `[!] debugger detected. RO{SLEEPY_DECOY}` and skips the ticket check. Exit code 2. The decoy `RO{SLEEPY_DECOY}` is not the flag.

A wrong ticket prints `[-] incorrect ticket. RO{SLEEPY_DECOY}` and exits with code 0. The decoy appears on a wrong ticket too, so it is not evidence of a tracer.

## IOC labels (for the IOC table)

- `github.com` (host and HTTP request on port 80): shared service.
- `example.com` (DNS probe): shared service.
- `operation-tidepool` and `restlessotter-lab/3.0`: classroom labels; useful only for lesson pivots.
- The `P_TRACED` check is behavior, not an IOC.

## Source note

`restlessotter.c` (updated Oct 14 16:17) matches the current build's behavior: the config, network, and anti-debug steps run only with exactly one argument, and the network helpers print nothing. The ticket is confirmed on macOS: `./restlessOtter TIDEPOOL-MAC-026` prints `[+] ticket accepted.` and `RO{MAC_OTTER_CURRENT}`.
