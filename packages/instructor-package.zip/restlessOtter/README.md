# Restless Otter

A benign macOS-oriented crackme for the Recorded Future Ghidra MCP class.

Restless Otter is a little more involved than Grumpy Ferret and Soggy Badger:

- Mach-O (the macOS executable format) native build target
- sysctl-based anti-debug check (`sysctl` is a macOS kernel query; the
  process `P_TRACED` flag is set when a debugger is attached)
- encrypted runtime config blob
- plain TCP HTTP reach-out to GitHub over port 80
- DNS probes for both the benign documentation domain and GitHub host
- 16-character ticket check with a per-byte transform plus rolling checksum
- flag encrypted with a key derived from the correct ticket
- application-controlled strings are stored as encrypted byte arrays

The binary is meant for reverse-engineering practice only. It has no persistence,
no destructive behavior, and does not require the network request to succeed in
order to solve the ticket check.

## Build

A prebuilt Mach-O, `restlessOtter`, is included. It is arm64 only, so it runs
on Apple Silicon Macs. On an Intel Mac, rebuild with `make release` before use.

On macOS:

```sh
make release
```

Debug build:

```sh
make debug
```

Quick string hygiene check:

```sh
make strings-check
```

The `strings-check` target looks for challenge strings that should not appear in
the stripped release binary. System/library strings may still appear, especially
in non-release builds.

## Suggested Analysis Path

Run the program with exactly one argument when you test it. With no argument it prints usage and stops before the config, network, and ticket steps.

1. Run `strings` on the release binary and note that the useful app strings are
   absent.
2. Identify the shared string decoder and label the encrypted byte arrays.
3. Decode the config blob to recover the host, path, DNS probe target, campaign,
   and HTTP User-Agent (the `agent` field, sent in the HTTP request header).
4. Find the sysctl anti-debug check and understand that it gates only the final
   ticket reveal.
5. Recover the 16-byte ticket validation table and invert the transform.
6. Use the recovered ticket to decrypt the flag blob.

## Safety Note

The default network target is GitHub over port 80, which normally returns a
redirect or small HTTP response. Adjust the encrypted config in source if you
want the traffic to go to infrastructure you own.

For your IOC table: `github.com` and `example.com` are shared services. The
campaign and agent values are classroom labels, not infrastructure.
