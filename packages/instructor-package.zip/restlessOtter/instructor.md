# restlessotter: Instructor Answer Key

Use this with `student.md`. Answers were verified against the Ghidra analysis of the current `restlessOtter` binary (SHA-256 `66cde9e0e9b3124667b4e676b9115ba10d72040cd9e8cf6e873f02bae59d5c13`, rebuilt on macOS and stripped). Sandbox expectations describe what the sample should do. Verify them against an actual sandbox run before class.

> **Source and binary agree on behavior.** `restlessotter.c` (updated Oct 14 16:17) matches the current build: the config, network, and anti-debug steps run only with exactly one argument, and the network helpers print nothing. The ticket checksum is confirmed: on macOS, `./restlessOtter TIDEPOOL-MAC-026` prints `[+] ticket accepted.` and `RO{MAC_OTTER_CURRENT}`. The compiled compare constant in the disassembly (`0x7c538b83`) is a compiler detail, not a mismatch.

> **Build note: the binary is stripped.** It was rebuilt on macOS with `make release` (`strip -x`). Ghidra shows no author function names, only imports and the Mach-O header. The address-based checks in this key were updated for that build (SHA-256 `66cde9e0…`), but they have not yet been re-checked in Ghidra. Re-import the binary and confirm the addresses before class. `make strings-check` fails on the code-signing identifier, which is the program name `restlessotter`, not on any challenge text.

> **Sandbox build note:** This is an arm64 Mach-O. Confirm the class sandbox can run Mach-O arm64 before assigning the sandbox steps. If it can't, the dynamic sections will not be testable.

---

## Setup

**Step 1. MD5:** `66cde9e0e9b3124667b4e676b9115ba10d72040cd9e8cf6e873f02bae59d5c13`

**Step 2. Linking:** Dynamically linked. The strings `/usr/lib/dyld` (`0x1000004ac`) and `/usr/lib/libSystem.B.dylib` (`0x100000538`) are in the Mach-O load commands, and the imports come from `libSystem`.

**Step 3. Function groups (18 total, stripped build):**
- Author: 2 in Ghidra. `entry` (the program's `main`, at `0x1000005b8`) and `FUN_100001418` (the string decoder). The compiler inlined the other helpers into `entry`. The `_ro_*` names come from the source only, so label the functions yourself.
- Boilerplate: 0. The Mach-O entry point points directly at `main`, so there is no C runtime stub.
- Library: 16 imports from `libSystem` (`getaddrinfo`, `socket`, `connect`, `send`, `recv`, `sysctl`, `getpid`, `write`, and others).

**Step 4. `main` address:** `0x1000005b8`. It is the Mach-O entry point (`LC_MAIN`), so there is no separate startup code. Its first call prints the banner.

**Check:** The banner string is `restlessotter v3.0 -- "hold still"`, at `0x1000015f8`.

**Control flow in `main` (`entry` in Ghidra):**
1. Print the banner (always).
2. If `argc != 2`: print `usage: <argv[0]> <ticket>`, return 1. Nothing else runs.
3. If `argc == 2`: decode the config and port, parse the config, run the two DNS probes, run the phone-home request, run the anti-debug check, then run the ticket check and print the result.

---

## Finding 1: Encrypted config

**Decoder:** `_ro_decode(dst, src, len, seed)`. Each output byte is `src[i] ^ key[i]`. The key comes from `_ro_key_step`, which keeps a running state byte:

```
state = (state * 0x21 + 0x11 + i) & 0xff
key[i] = state ^ ((i * 0x1d + 0x5a) & 0xff)
```

**Config call in `main`:** only in the `argc == 2` branch. Source `0x10000162c`, length `0x5e` (94), seed `0x77`.

**Decoded config:**

```text
host=github.com;path=/;dns=example.com;campaign=operation-tidepool;agent=restlessotter-lab/3.0
```

**Field offsets (in the config structure):** `host` at `+0x00`, `path` at `+0x40`, `dns` at `+0xa0`, `campaign` at `+0xe0`, `agent` at `+0x120`.

**Values:**
- `host` = `github.com`
- `path` = `/`
- `dns` = `example.com`
- `campaign` = `operation-tidepool`
- `agent` = `restlessotter-lab/3.0`

**Printed at runtime:** No. The current binary does not print the decoded config. Students can't get the config from a run, so it must come from static analysis.

**Expected tags:** Decoder, offsets, and values are **[Code]**. Whether the sandbox shows the lookups is **[Sandbox]**.

---

## Finding 2: Network activity

**Order in `main` (only when `argc == 2`):**
1. `_ro_dns_probe(cfg.dns, port)`: resolves `example.com`
2. `_ro_dns_probe(cfg.host, port)`: resolves `github.com`
3. `_ro_phone_home(cfg, port)`: connects to `github.com` and sends the request

- **DNS helper:** `_ro_dns_probe`, which calls `getaddrinfo`. Hostnames in order: `example.com`, `github.com`.
- **Connection helper:** `_ro_connect_first`, which calls `getaddrinfo`, then `socket` and `connect` for each address in turn.
- **Hints struct:** `ai_family = AF_UNSPEC (0)`, `ai_socktype = SOCK_STREAM (1)`. So the protocol is TCP, with IPv4 or IPv6 allowed.
- **Port:** `80`, decoded from the 2-byte blob at `0x10000168a` (seed `0x24`).
- **Timeouts:** None. The binary doesn't import `setsockopt`.
- **Request text** (pieces decoded from the blobs at `0x1000016e1`, `0x1000016e5`, `0x1000016f6`, `0x100001704`):

  ```
  GET / HTTP/1.0
  Host: github.com
  User-Agent: restlessotter-lab/3.0
  Connection: close

  ```

  Written as bytes: `GET /` + ` HTTP/1.0\r\nHost: ` + host + `\r\nUser-Agent: ` + agent + `\r\nConnection: close\r\n\r\n`.
- **Response:** Up to 256 bytes are read and then discarded. Nothing is printed.

**Failure paths (all silent):**

| Failure | What the program does |
|---|---|
| `getaddrinfo` fails in the DNS probe | Returns. Prints nothing. |
| `getaddrinfo`, `socket`, or `connect` fails in `_ro_connect_first` | Tries the next address. If none connects, returns -1 and the phone-home step does nothing. Prints nothing. |
| `send` fails | Closes the socket and returns. Prints nothing. |
| `recv` returns nothing | The result is ignored. Prints nothing. |

**Output on success:** None from the network steps. The only visible output on a run with one argument is the banner, then the ticket result.

**Expected tags:** Hostnames, request text, port, and timeouts are **[Code]**. Whether the connection succeeds in the sandbox is **[Sandbox]**.

**Recorded Future:** Results depend on the live service. Expected: `example.com` is reserved for documentation (RFC 2606) and `github.com` is a shared service with a clean reputation. The campaign and agent values are classroom labels, not infrastructure.

---

## Finding 3: Anti-debugging check

- **Function:** `_ro_is_debugged`. It calls `getpid`, then `sysctl` with MIB `{CTL_KERN (1), KERN_PROC (14), KERN_PROC_PID (1), pid}`.
- **Bit tested:** `kp_proc.p_flag & 0x800` (`P_TRACED`). Traced when the bit is set. The function returns 0 if `sysctl` fails.
- **Call site:** In `main`, only in the `argc == 2` branch, after the DNS and phone-home steps.
- **Traced output:**

  ```text
  [!] debugger detected. RO{SLEEPY_DECOY}
  ```

  The function returns 2. The ticket check is skipped.
- **Decoy string:** `RO{SLEEPY_DECOY}` (at `0x1000016a3`). It is not the real flag.

**Expected tags:** The `sysctl` call, the MIB, the bit, and the output are **[Code]**. Whether the sandbox triggers the traced branch is **[Sandbox]**. The sandbox normally doesn't attach a debugger, so the branch should not run. Students should predict that and check it against the report.

---

## Finding 4: Ticket check

- **Length:** The ticket must be exactly 16 bytes (`_ro_len == 0x10`).
- **Per-byte transform:** for position `i` with input byte `c`:

  ```
  v = c ^ ((i * 13 + 0x41) & 0xff)
  v = (v + i * 7 + 0x23) & 0xff
  v = rol8(v, (i % 5) + 1)
  compare v with SERIAL[i]
  ```

- **Serial table:** 16 bytes at `0x10000171b`:

  ```text
  70 c4 82 56 8c 26 34 21 fd ab d7 0c 3b 85 49 7d
  ```

- **Rolling checksum:** starts at `0x6d2b79f5`. For each passing byte `v`: `h = ((h ^ v) * 0x45d9f3b + i + 0x1337) & 0xffffffff`. The final value must be `0x7c539eb9`.
- **Correct ticket:** `TIDEPOOL-MAC-026`. It passes all 16 steps and gives the final checksum `0x7c539eb9`.
- **Solving by reversal:** For each position, take the table byte, rotate right by `(i % 5) + 1`, subtract `i * 7 + 0x23`, then XOR with `i * 13 + 0x41`. Each position has exactly one answer, so the ticket is unique.

**Output** (only in the `argc == 2` branch, when not traced):
- Correct: `\n[+] ticket accepted.\n`, then the flag (Finding 5).
- Wrong: `\n[-] incorrect ticket. RO{SLEEPY_DECOY}\n`. The decoy is printed on a wrong ticket too.

**Expected tags:** Transform, table, checksum, and ticket are **[Code]**.

---

## Finding 5: Flag

- **Blob:** 21 bytes at `0x10000172b`. Key-stream seed `0x9b`.
- **Per-byte calculation:**

  ```
  key_byte = keystream[i]    (same _ro_key_step, seed 0x9b)
  flag[i] = blob[i] ^ ((ticket[i % 16] + i * 0x1f - 0x59) & 0xff) ^ key_byte
  ```

- **Ticket bytes used:** `ticket[i % 16]`. The flag depends on the ticket, so a wrong ticket gives garbage.
- **Decoded flag:** `RO{MAC_OTTER_CURRENT}` (21 characters, starts with `RO{`, ends with `}`).
- **Output on success:** the `[+] ticket accepted.` line, then `RO{MAC_OTTER_CURRENT}` on its own line.

**Expected tags:** Blob, seed, calculation, and flag are **[Code]**.

---

## What the sandbox should show

| Run | Expected behavior |
|---|---|
| No argument | Banner, then `usage: <name> <ticket>`. Exit code 1. **No network activity.** No flag. |
| One argument, not traced | DNS lookups for `example.com` and `github.com`. TCP connection to `github.com:80` and `GET /` with `User-Agent: restlessotter-lab/3.0`. No network output printed. Ticket check runs. A wrong ticket prints the decoy. |
| One argument, traced | Same network activity. Prints `[!] debugger detected. RO{SLEEPY_DECOY}`. Ticket check skipped. Exit code 2. |
| Correct ticket `TIDEPOOL-MAC-026` | Network activity, then `[+] ticket accepted.` and `RO{MAC_OTTER_CURRENT}`. Exit code 0. |

Notes:
- A sandbox without network access makes `getaddrinfo` fail. The program prints nothing for that, so students will see no difference in stdout. They need the sandbox's network log to see the attempt.
- The debugger check normally doesn't trigger in a standard sandbox.
- Because the network steps are silent, the sandbox's network capture is the only evidence of them.

---

## IOCs (expected answers)

| Type | Value | Source | Tag |
|---|---|---|---|
| Domain | `github.com` | config `host` | Code |
| Domain | `example.com` | config `dns` | Code |
| Hostname | `github.com` (phone-home) | config `host` | Code |
| HTTP request | `GET /` with `Host: github.com`, port 80 | string pieces in `_ro_phone_home` | Code |
| User agent | `restlessotter-lab/3.0` | config `agent` | Code |
| Campaign label | `operation-tidepool` | config `campaign` | Code |
| Port | `80` | 2-byte blob at `0x10000168a` | Code |

**Shared services:** `github.com` and `example.com`. Not malicious infrastructure. **Classroom labels:** `operation-tidepool` and `restlessotter-lab/3.0`. These are useful only for lesson pivots.

---

## MITRE ATT&CK mapping (expected answers)

Verify these IDs against the ATT&CK version you use before class. They are the expected answers, not a verified list.

| Behavior | Expected technique | Evidence | Tag |
|---|---|---|---|
| Config decrypted at runtime | T1140 Deobfuscate/Decode Files or Information | `_ro_decode` with seed `0x77` in `main` | Code |
| DNS lookups and HTTP request | T1071.001 Application Layer Protocol: Web Protocols | `getaddrinfo` in `_ro_dns_probe`; `GET /` in `_ro_phone_home` | Code |
| Debugger check via `sysctl` | T1622 Debugger Evasion | `_ro_is_debugged`, `P_TRACED` (0x800) | Code |
| Ticket validation | No clean technique. Treat as a crackme check and don't force a mapping. | `_ro_check_ticket` | Inferred |
| Flag decrypted at runtime | T1140 Deobfuscate/Decode Files or Information | `_ro_reveal_flag`, seed `0x9b` | Code |

Students may also argue for T1497 (Virtualization/Sandbox Evasion) for the debugger check. Accept it if they justify it.

---

## Analyst report: what good looks like

- **Summary:** The sample is a benign macOS crackme. With one argument, it decrypts its config, does two DNS lookups and one HTTP request to `github.com`, checks for a debugger with `sysctl`, and reveals a flag only when a 16-character ticket passes a per-byte transform and a checksum. With no argument, it prints a usage line and exits. The decoded flag is a classroom reward, not a real goal.
- **Detection ideas:** Good answers name specific, reliable indicators, such as the `GET /` request with the `restlessotter-lab/3.0` user agent, or the `sysctl` `P_TRACED` check together with the decoy string. Fragile answers rely on the DNS lookups or on `github.com` alone, since many legitimate programs make those. Good answers may also note that the program makes its network calls silently, so stdout gives no hint of them.
- **Sandbox comparison:** Good answers say which static findings the sandbox confirmed. They explain gaps, such as the traced branch not running, or the network steps failing without outbound access. They note that a no-argument run should show no network activity.

---

## Grading rubric (suggested)

| Area | Points | Key evidence |
|---|---|---|
| 1. Config | | Decoder, seed, and the five decoded values |
| 2. Network | | Argument count gate, order of DNS hosts, port 80, request text, silent failures |
| 3. Anti-debug | | `sysctl`, `P_TRACED`, decoy output, call position |
| 4. Ticket | | `TIDEPOOL-MAC-026`, checksum `0x7c539eb9`, serial table |
| 5. Flag | | `RO{MAC_OTTER_CURRENT}`, seed `0x9b`, ticket dependence |
| Labeling | | Helpers and data labeled, names describe purpose |
| Confidence tags | | Each answer tagged correctly |
| Predictions | | Written before the sandbox, compared after |
| IOC table | | Complete, with sources |
| ATT&CK mapping | | Plausible IDs with evidence |
| Analyst report | | Three paragraphs, supported by the findings |

Set point values before grading. The rubric above does not include them.

---

## Notes for the instructor

- **Source and binary.** The source now matches the build's behavior (see the note at the top). The checksum is confirmed by a Mac run. The Mac run used the same SHA-256 (`66cde9e0…`) as the shipped binary.
- **Ghidra check (stripped build, 66cde9e0):** the data addresses, the entry point `0x1000005b8`, the decoder call with `Zb*DE`, the port blob, the decoy and flag strings, and the sysctl `P_TRACED` test (`0x800`) were confirmed against the active program. The ticket checksum constant is still open; see the build note.
- **Sandbox support for Mach-O arm64** must be confirmed before assigning the dynamic steps.
- **Changes from the previous build (MD5 `5901c284...`):** the config, DNS, phone-home, and anti-debug steps now run only with one argument. The config is no longer printed, and the network helpers print nothing. The crypto (config key stream, port, ticket table, checksum, flag) is unchanged, and so are the decoded values and the answers.
- **`SOLUTION.md` doesn't mention the argument gate.** It says the binary resolves and connects, which still holds, but it doesn't say the network steps only run with one argument. Add that note before handing it out.
