# Vexed Wolverine — instructor notes

This file, the source tree and everything in `instructor/` are spoilers.
Distribute only `student/` or the student ZIP.

## What counts as a solution

Recover the unique 32-character ticket and the genuine `VW{...}` flag, then
explain the evidence connecting them. The literal flags in the executable
are bait. The exact answers are in `answers.json`; avoid showing that file
during the exercise.

`python3 instructor/solve_offline.py` prints the solution. It does not read
`answers.json` or regenerate the secret ticket. It starts from
`container.json`, an instructor convenience representation of the shards and
encrypted bytes embedded in the executable. A student must first recover
those bytes and their relationships through Ghidra or memory inspection.

## The path through the program

1. `assemble_root` combines two 32-byte shards using permuted indices,
   byte rotations and XOR. The result is the outer ChaCha20 key.
2. `unpack_container` checks the encrypted container's SHA-256 digest,
   decrypts it and parses its lengths, nonces, opcode tables, string offsets
   and flag digest. Runtime strings use a separate derived key.
3. A worker thread runs `execute_worker`, a flattened state machine with
   encoded transitions and an opaque predicate. Its thread-local cookie
   helps connect the state machine to the second interpreter.
4. `stack_lane` decrypts and interprets 513 four-byte instructions. It
   reconstructs a 32-byte key, checks each instruction tag and verifies that
   all output bytes were produced. Its opcode map is randomized.
5. `register_lane` uses that key to decrypt 2,569 twelve-byte instructions.
   Operands and immediate values are masked, and instruction tags are
   checked. The real transform uses registers 0–7; registers 8–15 and some
   operations add noise. Eight comparisons constrain all input words.
6. `reveal_lane` derives the final key from the ticket, the first VM's output
   and the suffix `/f`. It decrypts the flag and verifies its SHA-256 digest.
   Returning success from validation without the correct input produces a
   decoy because the flag key is still wrong.

The input is 32 ASCII characters from `ABCDEFGHJKLMNPQRSTUVWXYZ23456789`,
read as eight little-endian words. The real transform consists of 48 rounds
of additions, XORs, rotations, swaps, multiplication by odd constants and
right-shift XORs. Every operation on the real words is reversible modulo
2^32. Work backward from the eight comparison targets, using modular
inverses for multiplication and successive doubled shifts to invert
`x ^ (x >> n)`. The offline solver demonstrates this and checks the recovered
ticket by replaying the forward transform before decrypting the flag.

The outer plaintext starts with `VWLAB01\0`. Its first 656 bytes hold the
header and tables; the remaining slices are the encrypted stack program,
register program, strings and flag. The generator and solver document the
exact layout. Keys for the stack program and strings are SHA-256 of the
root key followed by `/a` and `/s`, respectively. ChaCha20 starts at counter
one with separate 12-byte nonces.

## Staged hints

Give one hint at a time. Use the challenge as independent analysis practice;
it is too large to promise a complete walkthrough in the remaining minutes.

1. Strings are leads, not answers. Follow the result-printing path backward.
2. Look for a large data section, a digest comparison and a decoder. The
   apparent cryptographic barrier has recoverable key material.
3. A decoded container holds more encrypted data and two different
   interpreter instruction formats. Identify the dispatch loops.
4. Execute or emulate the first interpreter to recover the second one's key.
5. Separate the real input registers from junk registers and identify the
   comparison targets. The arithmetic transforms are reversible.
6. Recover the input by reversing the real operations. Use it to derive the
   final flag key rather than trying to patch a single branch.

## Rehearsal and debugging

Run `make test`. It checks a correct ticket in normal and lab modes, 39
invalid inputs, missing input, container tampering and a test build that
forces validation success. It also checks SHA-256 padding boundaries,
ChaCha20 reference vectors, hidden answer strings and relevant imports.
The generated report records the tests actually performed.

The anti-debug gate reads Linux `TracerPid`, resolves Windows
`IsDebuggerPresent` by a ROR13-plus-add export-name hash, or uses macOS
`sysctl`/`P_TRACED` in the source branch. A 90-second elapsed-time gate can
send a heavily paused debugger session to a decoy. Neither check crashes or
modifies the host. For an instructor demonstration, set `VW_LAB_MODE=1` to
disable these two gates; validation and flag-key binding still apply. Reveal
this option only when it helps the lesson.

Linux runtime and offline solving were tested. Windows was cross-compiled
and statically inspected; rehearse the exact PE on Windows. macOS source
support is untested, with no supplied Mach-O. Anti-debug and long-pause paths
are implemented but were not exercised under each platform's debugger.

## Scope of the simulated techniques

This challenge demonstrates obfuscation and analysis obstacles. It does not
implement malware deployment, command-and-control, persistence or injection.
The worker thread runs the program's own function. Encrypted bytecode is
interpreted in ordinary memory, with no RWX allocation or native payload
execution. The fictional network strings are never used for communication.
