# Vexed Wolverine

An expert reserve crackme for the Recorded Future Ghidra AI MCP class. Keep it
in your back pocket for students who finish the three core exercises early,
or offer it as a take-home challenge. It does not add another hour to the
class schedule.

The difficulty comes from layered analysis: encrypted configuration and
bytecode, two different virtual machines, shuffled opcode mappings, masked
operands, a flattened execution flow, reversible arithmetic, thread-local
state, integrity checks, anti-debugging and convincing decoys. It is designed
to be much harder than the core exercises, but has not been benchmarked
against experienced students.

The challenge is solvable by reconstructing and reversing its validation
logic. There is no need to brute-force a cryptographic preimage. The real
flag depends on the correct ticket, so patching the final validation result
alone does not recover it.

## Handout and instructor material

- `student/` holds the handout: the Linux build, its checksum, and the student
  guide. The Windows build is kept in `instructor/dist/` and is not handed out.
  The handout is the Linux-only copy in `student/`.
- `src/` and `instructor/` contain spoilers, source, generated data, answers,
  an offline solver and verification tools. Keep these out of the handout.
- [Instructor solution and staged hints](instructor/SOLUTION.md) explain how
  the layers fit together and how to rehearse the challenge.

## Build and validation

Run `make all` to build Linux with GCC and Windows with MinGW-w64.
Run `make test` for the offline qualification checks. Python 3 and `objdump`
are required. `make generate` regenerates the deterministic challenge data.

The supplied Linux executable passed 57 checks covering the independent
solve, successful and unsuccessful inputs, container tampering, flag-key
binding, cryptographic reference vectors and import inspection. The Windows
PE compiled and passed static checks; it has not been run on Windows here.
Rehearse it on the intended Windows lab before handing it out. macOS source
branches are included, but no Mach-O binary or macOS runtime validation is
provided. Details and binary hashes are in `instructor/validation.json`.

## Benign behavior

The programs validate an argument, interpret their own embedded data and
print a result. They run one local worker thread and query debugger status.
They perform no networking, persistence, process injection, process spawning,
credential collection, privilege changes or file writes. The encrypted
programs are interpreter data; they are never native executable payloads.
The apparent endpoint strings are decoys and are never contacted.
