# Grumpy Ferret

Linux x86-64 classroom crackme. Run `./grumpyferret <serial>`.
Python 3 at `/usr/bin/python3` is needed for the additional embedded
classroom stage. The embedded stage reads the public YouTube page without a supplied API
key or login. The instructor supplies an optional prepared fixture run
for classrooms where automated page access is unavailable. A remote
lookup failure does not stop the original serial exercise.

Recover the serial and flag, explain the configuration and embedded stage,
and trace the origin of any downloaded classroom resource. Use code and
runtime evidence to distinguish successful requests from skipped behavior.
This educational program makes benign network requests and prints a text
flag. It does not execute downloaded content or provide a real command-and-control (C2) server. Record your indicators in an IOC table: type, value, source, status and label (classroom decoy or shared service).
