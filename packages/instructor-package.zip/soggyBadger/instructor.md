# soggybadger: Instructor Answer Key

Answers for `student.md`. Verified against the loaded Ghidra program (`soggyBadger.exe`, MD5 `09c71fb061435a07d50c43f3bd31c37c`). Ghidra names are unchanged: `main` is still `FUN_140007d80`.

Do not distribute this file to students.

---

## Setup

**Step 1. MD5:** `09c71fb061435a07d50c43f3bd31c37c`

**Step 2. Imported DLLs:** `ADVAPI32.dll`, `KERNEL32.dll`, `MSVCRT.dll`, `WININET.dll`, `WS2_32.dll`
- Registry: `ADVAPI32.dll` (`RegCreateKeyExA`, `RegSetValueExA`, `RegDeleteValueA`, `RegDeleteKeyA`)
- Networking: `WS2_32.dll` (`WSAStartup`, `getaddrinfo`), `WININET.dll` (`InternetOpenA`, `InternetOpenUrlA`, `InternetReadFile`)
- Synchronization: `KERNEL32.dll` (`CreateMutexA`, critical section calls)

**Step 3. `main` address:** `0x140007d80` (`FUN_140007d80`, unlabeled)
- Reached from `entry` (`0x140001410`) → `FUN_140001190` (CRT startup), which ends with `FUN_140007d80(argc, argv)`.
- Banner string `"soggybadger v2.0 -- \"who's a good boy\""` is at `0x14000a060`, printed first in `main`.
- TLS callbacks: `tls_callback_1` (`0x1400017c0`) and `tls_callback_0` (`0x1400017f0`) run before `entry`. Both call `FUN_140002290`, which initializes or tears down a critical section depending on the callback reason. They are not part of the stage list below.

**Step 4. Stages in `main` (in order):**

| Stage | Function or call |
|---|---|
| Banner | `FUN_140001480` (printf wrapper), banner string at `0x14000a060` |
| Winsock init | `WSAStartup` |
| Mutex | `CreateMutexA` + `GetLastError` |
| Config build | Inline in `main` (character copies from `0x14000a370`, `0x14000a390`, `0x14000a3c0`) |
| Registry check-in | `RegCreateKeyExA`, `RegSetValueExA` |
| DNS probes | `FUN_1400014d0` called twice (`getaddrinfo`) |
| Phone-home | `FUN_140001610` (`sprintf`-style URL build), `InternetOpenA`, `InternetOpenUrlA`, `InternetReadFile` |
| Anti-debug gate | `IsDebuggerPresent` + PEB read (`gs:[0x60]`, byte `+2`) |
| Hash check | Inline loop in `main`, compared to `0xA2AC2ABD` |
| Flag reveal | Inline XOR loop in `main` |
| Cleanup | `RegDeleteValueA`, `RegDeleteKeyA`, `RegCloseKey`, `CloseHandle`, `WSACleanup` |

**Check:** The banner string's xref is in `main` (`140007da7`). The config builder reads are in `main`.

---

## Finding 1: The hidden config (stack strings)

**Step 1. Builder functions and values:** No separate builder functions. All copies are inline in `main`, before the registry step.
- Mutex: copied from `0x14000a370` (`SoggyBadgerSingleton_Mut`), plus immediate `0x7865` (`"ex"`).
- Domain (fake), IP (fake), domain (safe): copied from `0x14000a390` (`c2.soggybadger-demo.inva` / `203.0.11` / `example.`), plus immediates `"lid"`, `"3.9"`, and `"com"`.
- Campaign: copied from `0x14000a3c0` (`operation-wet-bl`), plus immediates `"anke"` and `"t"`.

**Step 2. Rebuilt values:**
- Mutex name: `SoggyBadgerSingleton_Mutex`
- Domain (fake): `c2.soggybadger-demo.invalid`
- IP (fake): `203.0.113.9`
- Domain (safe): `example.com`
- Campaign: `operation-wet-blanket`

**Step 3. Explanation:** The string list shows `c2.soggybadger-demo.inva203.0.11example.` and `operation-wet-bl` as joined fragments. The domain, IP, and safe domain share one blob, and each value's tail is stored as an immediate in the code, so no full value appears as a single string.

**Check:** The rebuilt values match the `[*] config:` line that `main` prints (`domain=%s ip=%s safe=%s campaign=%s`).

**Confidence:** [Code]

---

## Finding 2: Host telemetry and network activity

**Step 1. Mutex:** `SoggyBadgerSingleton_Mutex`. Checks for an existing mutex: yes. `GetLastError() == 0xB7` (`ERROR_ALREADY_EXISTS`) selects the log text "already existed" versus "created". It does not change control flow.

**Step 2. Registry:** Key path `Software\SoggyBadgerDemo` under `HKEY_CURRENT_USER`. Value name `Marker`, data `soggybadger-demo-marker`. Cleaned up: yes. `RegDeleteValueA` and `RegDeleteKeyA` run before exit, but only if `RegCreateKeyExA` succeeded.

**Step 3. DNS function:** `getaddrinfo` (inside `FUN_1400014d0`). Hostnames in order: `c2.soggybadger-demo.invalid`, then `example.com`.

**Step 4. WinINet functions:** `InternetOpenA`, `InternetOpenUrlA` (plus `InternetReadFile`). URL: `http://example.com/` (built with `"http://%s/"` from the safe domain).

**Step 5. Recorded Future lookups:** Not verifiable from the binary. Expected answers, from the RFC reserved-name standards:
- `c2.soggybadger-demo.invalid` → reserved `.invalid` TLD (RFC 2606). Not a live domain.
- `example.com` → reserved example domain (RFC 2606). Not a live domain.
- `203.0.113.9` → TEST-NET-3 documentation range `203.0.113.0/24` (RFC 5737). Not routable.

**Check:** The mutex name and registry key are reached through `main`'s inline builders. The `snprintf` URL uses the safe domain (`example.com`), not the fake one.

**Predict and compare:** The sandbox should show mutex creation, registry key create and delete, DNS lookups for both hostnames in order, and an HTTP request to `http://example.com/`. Fill in the sandbox result after the report is available.

**Confidence:** Mutex, registry, and DNS: [Code]. Sandbox confirmation: [Sandbox].

---

## Finding 3: The anti-debugging checks

**Step 1. Checks:**
- Check 1: `IsDebuggerPresent` (`KERNEL32.dll`), called in `main`.
- Check 2: Direct PEB read through `gs:[0x60]`, then a byte read at offset `+2` (`BeingDebugged`).

**Step 2. Offset and value:** Offset `2` in the PEB. "Being debugged" means the byte is nonzero.

**Step 3. Output:** `"\n[!] tracer detected. backup_hash=0xDEADBEEF\nSB{TRY_HARDER}\n"`. Return value 1.

**Step 4. Steps before the gate:** Banner, mutex, config build, registry check-in, DNS probes, phone-home. The gate sits before the hash comparison and protects only the final check. The `argc < 2` usage check runs before the gate, in the other branch of the same `if`.

**Check:** The PEB read is a direct memory read (`gs:[0x60]`, then byte `+2`), not an API call, and sits beside the `IsDebuggerPresent` call.

**Predict and compare:** A sandbox that does not attach a debugger or set `BeingDebugged` will not trigger the decoy branch. Fill in the sandbox result after the report is available.

**Confidence:** [Code]

---

## Finding 4: The unlock check (rolling hash)

**Step 1. Hash function:** The loop is inline in `main`, not a separate function. Each step rotates the running 32-bit value right by 13 bits, then adds the character: `h = ror32(h, 13) + c`, starting from `h = 0`.

**Step 2. Target:** `0xA2AC2ABD`, a fixed 32-bit constant compared at the end of the loop.

**Step 3. Matching candidate:** `ADVAPI32` (uppercase base name of an imported DLL), hash `0xA2AC2ABD`.
- Other candidates, none match: `KERNEL32` = `0x8CB0FCBB`, `MSVCRT` = `0x2E95413B`, `WININET` = `0x1588F3F9`, `WS2_32` = `0xE59D481D`.

**Step 4. Output:**
- Correct: `"\n[+] hash matched.\n" + flag` (flag is decoded in Finding 5).
- Wrong: `"\n[-] wrong. SB{NOT_TODAY}\n"`.

**Check:** Rehashing `ADVAPI32` with the same steps gives `0xA2AC2ABD`. No other imported DLL base name matches.

**Confidence:** [Code]

---

## Finding 5: The flag

**Step 1. Encoded data and key:**
- Encoded data: 21 bytes at `0x14000a350`.
- Key: 6 bytes at `0x14000a365`.
- Lengths: 21 and 6. The loop runs 21 iterations and indexes the key with `i % 6`.

**Step 2. Raw bytes and decoded flag:**
- Key (hex): `2F C4 88 51 DA 06`
- Encoded (hex): `7C 86 F3 02 8E 47 6C 8F D7 02 8E 54 66 8A CF 02 85 51 66 8A F5`
- Flag: `SB{STACK_STRINGS_WIN}` (21 characters)

**Step 3. Output:** `"\n[+] hash matched.\n" + flag + "\n"`. The "hash matched" message comes before the flag, in the same branch as Finding 4.

**Check:** The decoded flag is 21 characters, starts with `SB{`, and ends with `}`.

**Confidence:** [Code]

---

## Indicators of compromise (IOCs)

| Type | Value | Source (address or string) | Confidence tag |
|---|---|---|---|
| Mutex | `SoggyBadgerSingleton_Mutex` (host indicator, not a network one) | Built in `main` from `0x14000a370` + immediate `"ex"` | [Code] |
| Registry key | `HKCU\Software\SoggyBadgerDemo` (value `Marker` = `soggybadger-demo-marker`) | Strings at `0x14000a131`, `0x14000a17c` | [Code] |
| Domain | `c2.soggybadger-demo.invalid` (classroom decoy) | `0x14000a390` + immediate `"lid"` | [Code] |
| Domain | `example.com` (shared service, not a live C2) | `0x14000a390` + immediate `"com"` | [Code] |
| IP | `203.0.113.9` (classroom decoy, TEST-NET-3) | `0x14000a390` + immediate `"3.9"` | [Code] |
| URL | `http://example.com/` | `"http://%s/"` at `0x14000a03d` | [Code] |
| Imported DLL | `ADVAPI32.dll`, `KERNEL32.dll`, `MSVCRT.dll`, `WININET.dll`, `WS2_32.dll` | Import table strings `0x14000f8a0` to `0x14000f9c4` | [Code] |

---

## MITRE ATT&CK mapping

| Behavior | Technique ID and name | Evidence (address or string) | Confidence tag |
|---|---|---|---|
| Config built on the stack | T1027 Obfuscated Files or Information | Inline char copies in `main` from `0x14000a370`, `0x14000a390`, `0x14000a3c0` | [Inferred] |
| Named mutex | No dedicated technique | `CreateMutexA` with `SoggyBadgerSingleton_Mutex`. Record as a host indicator only | [Inferred] |
| Registry check-in | T1112 Modify Registry | `RegCreateKeyExA` / `RegSetValueExA`, cleanup via `RegDeleteValueA` / `RegDeleteKeyA` | [Code] |
| DNS probes and HTTP request | T1016 System Network Configuration Discovery (DNS probes); T1071.001 Application Layer Protocol: Web Protocols (HTTP) | `getaddrinfo` in `FUN_1400014d0`; `InternetOpenUrlA` with `http://example.com/` | [Inferred] |
| Anti-debug checks | T1622 Debugger Evasion | `IsDebuggerPresent` and PEB `BeingDebugged` read (`gs:[0x60]+2`) | [Code] |
| Rolling-hash unlock | T1480 Execution Guardrails (loose fit) | Rotate-and-add hash compared to `0xA2AC2ABD` | [Inferred] |
| Flag decoded at runtime | T1140 Deobfuscate/Decode Files or Information | 21-iteration XOR loop, key at `0x14000a365` | [Code] |

---

## Analyst report (sample answers)

1. **Summary:** `soggyBadger.exe` is a demo implant. It creates a mutex and a registry marker, resolves two hostnames, and makes one HTTP request to `example.com`. It hides its config on the stack, checks for a debugger, and only reveals a flag when a rolling-hash argument matches the constant `0xA2AC2ABD`. The flag (`SB{STACK_STRINGS_WIN}`) suggests the goal is to teach stack-string deobfuscation.

2. **Detection ideas:** (a) Alert on creation of `HKCU\Software\SoggyBadgerDemo` with value `Marker`. It is reliable because the string is hard-coded, but fragile because an attacker can rename it. (b) Alert on the mutex name `SoggyBadgerSingleton_Mutex`. It is reliable for this build, but fragile because a rebuild or a different campaign changes it.

3. **Sandbox comparison:** Fill in after the sandbox report. Expected: the mutex, registry, DNS, and HTTP events appear. The anti-debug decoy and the flag output may not appear, which would show that the sandbox does not attach a debugger and does not supply the correct argument.

---

## Notes for the instructor

- **Function names are unlabeled in Ghidra.** `main` is `FUN_140007d80`, the DNS helper is `FUN_1400014d0`, and the URL builder is `FUN_140001610`. Students are expected to label these.
- **Expected sandbox results** are predictions, not confirmed. Fill in after the report is provided.
