# grumpyferret: Student Notes

Name: ______________________

Your notes must cover all five findings below to receive full credit. For each one, record:

- **Where:** the address or function where you found it
- **What:** what the code does, in your own words
- **How:** the steps or reasoning you used to find it

Write your own notes. Do not paste output from an AI tool.

---

## Finding 1: Runtime config

`main` decodes a configuration block (`ens`, `ip`, `domain`, `safe`, `campaign`) before it starts any network activity. The program does not print the decoded values, so you recover them from the code.

- Find the encoded data and the key that decodes it.
- Explain how the config is parsed and which values are used later.
- Explain what the `GF_OFFLINE` environment variable changes.

## Finding 2: Network activity

When `GF_OFFLINE` is not set, the program contacts an external host.

- Identify the host and the protocol the program uses.
- Explain what the program sends and what it does with the response.
- Explain what happens when DNS or connect fails.

## Finding 3: Hidden payload

`main` builds a buffer from encrypted data, then starts an external program with it.

- Identify the program that gets started and what file it runs.
- Explain how the buffer is decrypted.
- Describe what the decrypted content does, based on your analysis. You do not need to run it.

## Finding 4: Anti-analysis check

The program checks whether something is attached to it before it reveals the flag.

- Identify the file it reads and the field it looks for.
- Explain what the program does when the check fails.
- Explain why running the program under a debugger changes its output.

## Finding 5: Serial and flag

The program accepts a serial on the command line and then decodes a flag.

- Explain the check the serial must pass, and show the steps you used to find the correct serial.
- Explain how the flag is decoded.
- Record the serial you found and the flag you decoded.

---

## Submission checklist

- [ ] Finding 1 complete
- [ ] Finding 2 complete
- [ ] Finding 3 complete
- [ ] Finding 4 complete
- [ ] Finding 5 complete, with serial and flag recorded
